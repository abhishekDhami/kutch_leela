const express = require('express');
const app = express();


   app.get('/Home', (req, res) => {
    const MongoClient = require('mongodb').MongoClient;
    const url = "mongodb+srv://abhidhamii:jtbjrlrxdxn7@cluster0-4p9cg.mongodb.net/test?retryWrites=true&w=majority";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("MyData");
  dbo.collection("userData").findOne({}, function(err, result) {
    if (err) throw err;
    console.log(result);
    res.send(result);
    db.close();
  });
});
        
  });

  app.get('/Contact', (req, res) => {
    res.sendFile('./views/contact.html',{root: __dirname });
   
});

app.get('/Login', (req, res) => {
  res.sendFile('./views/Login.html',{root: __dirname });
 
});

app.get('/User/*', (req, res) => {
  console.log(req.query.uname);
  res.sendFile('./views/user.html',{root: __dirname });
 
});



// str= cmd.run('node -v');




// Listen to the App Engine-specified port, or 8080 otherwisenpm
 const PORT = 3000;
  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
  });